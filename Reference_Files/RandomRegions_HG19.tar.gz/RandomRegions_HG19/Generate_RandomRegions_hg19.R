# Needs to be changed according to user #
refPath <- "/Users/skn/Desktop/Lab/MPRA_MIN6/CompiledCode/Reference_Files/RandomRegions_HG19/" 

#################################################################
numberRegions <- 10000
filename <- "RandomRegionsHG19_temp.bed"

random_region <- function(numberRegions, filename, refPath)
{
  setwd(refPath)
  
  #how many regions to sample?
  number <- numberRegions
  
  #how many bp to add to start
  span <- 200
  
  # Read and format hg19 chromosome size
  chrom.size <- read.table("hg19.chrom.sizes.txt")
  colnames(chrom.size) <- c("chr", "length")
  chrom.size$chr <- as.character(chrom.size$chr)
  chrom.size$CumulativeSum <- cumsum(as.numeric(chrom.size$length))
  
  #initialise some vectors for storing random coordinates
  my_random_start  <- vector(mode = "numeric", length = numberRegions)
  my_random_end    <- vector(mode = "numeric", length = numberRegions)
  my_random_chr    <- vector(mode = "character", length = numberRegions)
  
  set.seed(345)
  # loop through number of regions
  count <- 1
  while(count < number+1)
  {
    temp <- sample(1:chrom.size$CumulativeSum[nrow(chrom.size)],1)
    
    for(j in 1:nrow(chrom.size))
    {
      if(j == 1)
      { 
        if(temp < chrom.size$CumulativeSum[j]) 
        {
          if( (temp > chrom.size$CumulativeSum[j]-span) | (temp < span+1) ) { next }
          my_random_chr[count] <- chrom.size$chr[j]
          my_random_start[count] <- temp
          my_random_end[count] <- temp + span
          count <- count + 1
          next
        }
        next
      }
      
      if(temp > chrom.size$CumulativeSum[j-1] & temp < chrom.size$CumulativeSum[j]) 
      {
        if( (temp > chrom.size$CumulativeSum[j]-span) | (temp < chrom.size$CumulativeSum[j-1]+span) ) { next }
        my_random_chr[count] <- chrom.size$chr[j]
        my_random_start[count] <- temp - chrom.size$CumulativeSum[j-1]
        my_random_end[count] <- temp - chrom.size$CumulativeSum[j-1] + span
        count <- count + 1
        next
      }
    }
  }
  my_random_loci <- data.frame(chr=my_random_chr,
                               start=my_random_start,
                               end=my_random_end)
  write.table(my_random_loci, filename, quote=FALSE, sep="\t", col.names=FALSE, row.names=FALSE)
}

random_region(numberRegions, filename, refPath)