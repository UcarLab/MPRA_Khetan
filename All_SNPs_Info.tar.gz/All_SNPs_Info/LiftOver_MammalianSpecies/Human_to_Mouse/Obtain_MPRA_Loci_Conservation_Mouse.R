setwd("/Users/skn/Desktop/Lab/MPRA_MIN6/Reference_Files/All_SNPs_Info/LiftOver_MammalianSpecies/Human_to_Mouse/")

MPRA_Loci <- read.table("MPRA_Loci.bed", header=F)
colnames(MPRA_Loci) <- c("chr", "start", "end", "SNP")
MPRA_Loci$Conservation_Mouse <- 0

Filenames_List <- read.table("MPRA_Loci_hg19_to_mm9_Mapped_XYZ_Multiple.Names.txt", header=F)
for(i in 1:nrow(Filenames_List))
{
  file <- read.table(as.character(Filenames_List$V1[i]), header = F)
  SNPs <- unique(file$V4)
  MPRA_Loci[which(MPRA_Loci$SNP %in% SNPs),5] <- i
}
write.table(MPRA_Loci, file="./MPRA_Loci_Conservation_Mouse.bed", col.names = T, row.names = F, sep="\t", quote = F)