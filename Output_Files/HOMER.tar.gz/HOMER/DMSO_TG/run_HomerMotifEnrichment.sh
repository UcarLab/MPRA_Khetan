#!/bin/bash

cat DMSO_Enhancers.bed | sort -k1,1 -k2,2n | uniq > DMSO_Enhancers.bed.tmp
mv DMSO_Enhancers.bed.tmp DMSO_Enhancers.bed

cat TG_Enhancers.bed | sort -k1,1 -k2,2n | uniq > TG_Enhancers.bed.tmp
mv TG_Enhancers.bed.tmp TG_Enhancers.bed

findMotifsGenome.pl DMSO_Enhancers.bed hg19 /Users/skn/Desktop/Lab/MPRA_MIN6/HOMER/DMSO_TG/DMSO_TO_TG/ -bg TG_Enhancers.bed -size given

findMotifsGenome.pl TG_Enhancers.bed hg19 /Users/skn/Desktop/Lab/MPRA_MIN6/HOMER/DMSO_TG/TG_TO_DMSO/ -bg DMSO_Enhancers.bed -size given
