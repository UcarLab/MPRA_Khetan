#!/bin/bash

cat T2D_Enhnacer.bed | sort -k1,1 -k2,2n > Baseline_Enhancers.bed.tmp
mv Baseline_Enhancers.bed.tmp T2D_Enhnacer.bed

cat T2D_NotEnhnacer.bed | sort -k1,1 -k2,2n > Baseline_NoActivity.bed.tmp
mv Baseline_NoActivity.bed.tmp T2D_NotEnhnacer.bed

findMotifsGenome.pl T2D_Enhnacer.bed hg19 /Users/skn/Desktop/Lab/MPRA_MIN6/HOMER/T2D_Associated_Enhancers/ -bg T2D_NotEnhnacer.bed -size given
