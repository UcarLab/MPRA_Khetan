setwd("/Users/skn/Desktop/Lab/MPRA_MIN6/")
All_SNPs_Annotations <- read.table("./Outputs_All/All_SNPs_AllelicCalls_EnhancerCalls_WithAnnotations.txt", header=T)
All_SNPs_Annotations$EnhancerAnyConditions <- (rowSums(All_SNPs_Annotations[,c("REF_Baseline_EnhCall", "ALT_Baseline_EnhCall", 
                                                                               "REF_Plasmid_DMSO_EnhCall", "ALT_Plasmid_DMSO_EnhCall", 
                                                                               "REF_Plasmid_TG_EnhCall", "ALT_Plasmid_TG_EnhCall")])>0)*1
All_SNPs_Annotations <- All_SNPs_Annotations[which(All_SNPs_Annotations$T2D_Associated_Traits==1),]
All_SNPs_Annotations$CHR <- paste("chr", All_SNPs_Annotations$CHR, sep="")
All_SNPs_Annotations$End <- All_SNPs_Annotations$START+100
All_SNPs_Annotations$START <- All_SNPs_Annotations$START-100

T2D_NotEnhnacer <- All_SNPs_Annotations[which(All_SNPs_Annotations$EnhancerAnyConditions==0), c("CHR", "START", "End", "rsID")]
T2D_Enhnacer <- All_SNPs_Annotations[which(All_SNPs_Annotations$EnhancerAnyConditions==1), c("CHR", "START", "End", "rsID")]

write.table(T2D_NotEnhnacer, file="/Users/skn/Desktop/Lab/MPRA_MIN6/HOMER/T2D_Associated_Enhancers/T2D_NotEnhnacer.bed", col.names = F, row.names = F, quote = F, sep="\t")
write.table(T2D_Enhnacer, file="/Users/skn/Desktop/Lab/MPRA_MIN6/HOMER/T2D_Associated_Enhancers/T2D_Enhnacer.bed", col.names = F, row.names = F, quote = F, sep="\t")